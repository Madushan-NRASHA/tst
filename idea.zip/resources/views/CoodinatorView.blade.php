@extends('layouts.fronts', ['main_page' => 'yes'])

@section('content')
    <div class="content-wrapper">
      
        
         <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>View User Status</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('editor.dashboard') }}">User Details</a></li>
                            <li class="breadcrumb-item active">View user</li>
                        </ol>
                    </div>
                </div>
                </div>
        </section>
        <div class="d-flex justify-content-start" style="margin-left: 20px">
            <div class="card text-white bg-primary mb-3" style="width: 20rem;">
                <div class="card-header text-center">
                    <h4>User Details</h4>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><strong>{{ $user->name }}</strong></h5>
                    <p class="card-text">
                        <strong>Department:</strong> {{ $user->department->get_Department ?? 'No department assigned' }}<br>
                        <strong>Role:</strong> {{ $user->userType }}<br>
                        <strong>Emp No:</strong> {{ $user->Emp_id }}
                    </p>
                </div>

            </div>
        </div>


        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"></h3>
                            </div>
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th></th>
                                        <th>Company Name</th>
                                        <th>Task Description</th>
                                        
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Allocation time</th>
                                        <th>Duration</th>
                                        <th>Extra Time</th>
                                        <th>Status</th>
                                        <th>Coordinator Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($user->tasks as $task)
                                    <tr>

                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{$task->task_site}}</td>
                                            <td>{{ $task->task_name }}</td>
                                              <!--<td>{{$task->task_type}}</td>-->
                                              <!--<td>{{$task->qty}}</td>-->
                                            <td>{{ $task->start_date }}</td>
                                            <td>{{ $task->end_date }}</td>
                                        <td>{{$task->start_time}}::{{$task->end_time}}</td>
                                          <td>{{ $task->Duration_time }}</td>
                                        <td>{{$task->Extra_time}}</td>

                                        <td>
    <span class="badge
        @if($task->status === 'Done')
            bg-success
        @elseif($task->status === 'pending')
            bg-warning
        @else
            bg-secondary
        @endif
        px-3 py-2">
        {{ $task->status ?? 'Not specified' }}
    </span>
                                        </td>

                                        <td>
                                             <span class="badge
        @if($task->Coordinator_status === 'Done')
            bg-success
        @elseif($task->Coordinator_status === 'pending')
            bg-warning
        @else
            bg-secondary
        @endif
        px-3 py-2">
        {{$task->Coordinator_status ?? 'Not specified' }}
    </span>
                                        </td>
<td>
    <div class="d-flex gap-2 mt-3">
        <form action="{{ route('task.update.status', ['task' => $task->id]) }}" method="POST" class="me-2">
            @csrf
            @method('PUT')
            <input type="hidden" name="status" value="Done">
            <button type="submit" class="btn btn-success btn-sm">
                <i class="fas fa-check me-1"></i> Done
            </button>
        </form>

        <form action="{{ route('task.update.status', ['task' => $task->id]) }}" method="POST">
            @csrf
            @method('PUT')
            <input type="hidden" name="status" value="Not Done">
            <button type="submit" class="btn btn-danger btn-sm">
                <i class="fas fa-times me-1"></i> Not Done
            </button>
        </form>
        <form action="{{ route('task.update.status', ['task' => $task->id]) }}" method="POST">
            @csrf
            @method('PUT')
            <input type="hidden" name="status" value="pending">
            <button type="submit" class="btn btn-warning btn-sm">
                <i class="fas fa-times me-1"></i> Pending
            </button>
        </form>
    </div>

</td>
                                    </tr>
                                    @endforeach
                                    </tbody>
                                    <tfoot>
                                    <tr>

                                        <th></th>
                                        <th>Company Name</th>
                                        <th>Task Description</th>
                                        
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Allocation time</th>
                                        <th>Duration</th>
                                        <th>Extra Time</th>
                                        <th>Status</th>
                                        <th>Coordinator Status</th>
                                        <th>Action</th>

                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- /.content -->
    </div>

@endsection
