@extends('layouts.fonts', ['main_page' => 'yes'])
@section('content')

<style>
.table-responsive {
    overflow-x: visible;
    margin: 20px 0;
    width: 100%;
}

/* Base table styles */
.table {
    width: 150%;
    margin-bottom: 1rem;
    font-size: 0.9rem;
    table-layout: fixed;
}

/* Column widths */
.table th:nth-child(1) { width: 8%; }  /* # column */
.table th:nth-child(2) { width: 35%; } /* Activity */
.table th:nth-child(3) { width: 25%; } /* Company Name */
.table th:nth-child(4) { width: 10%; }  /* Start Date */
.table th:nth-child(5) { width: 10%; }  /* End Date */
.table th:nth-child(6) { width: 15%; }  /* Start Time */
.table th:nth-child(7) { width: 15%; }  /* End Time */
.table th:nth-child(8) { width: 10%; } /* Duration */
.table th:nth-child(9) { width: 12%; } /* Extra Time */
.table th:nth-child(10) { width: 10%; } /* Status */

/* Cell styles */
.table th,
.table td {
    padding: 0.5rem;
    vertical-align: middle;
    word-wrap: break-word;
    white-space: normal;
}

/* Header styles */
.thead-dark th {
    background-color: #343a40;
    color: white;
    font-weight: 500;
}

/* Status badge styles */
.badge {
    padding: 0.4em 0.6em;
    font-size: 85%;
    font-weight: 500;
    white-space: nowrap;
}

/* Striped rows */
.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0, 0, 0, 0.05);
}

/* Responsive adjustments for smaller screens */
@media screen and (max-width: 1200px) {
    .table {
        font-size: 0.8rem;
    }
    
    .table th,
    .table td {
        padding: 0.4rem;
    }
}

/* Optional: Add some spacing around the table title */
.text-dark.font-weight-bold.mt-4 {
    margin-bottom: 1rem;
}
</style>
    <div class="content-wrapper">
      
        
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <div class="col-sm-12">
                                            <h1 class="text-primary font-weight-bold text-center text-md-left">View User Status</h1>
                                        </div>
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="{{ route('admin.viewUser') }}">User Details</a></li>
                            <li class="breadcrumb-item active">View</li>
                        </ol>
                    </div>
                </div>

            </div>
        </section>

        <div class="container">
            <div class="card shadow-lg mt-4 mb-4" style="border-radius: 12px;">
                <!-- Card Header -->
                <div class="card-header bg-gradient-primary text-white text-center" style="border-radius: 12px 12px 0 0;">
                    <h3 class="card-title font-weight-bold">{{ $user->name }}</h3>
                </div>

                <!-- Card Body -->
                <div class="card-body" style="background-color: #f9f9f9;">
                    <div class="row">
                        <!-- Main Content -->
                        <div class="col-md-8 mb-4">
                            <h4 class="text-dark font-weight-bold">User Details</h4>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <strong>Email:</strong> <span class="text-info">{{ $user->email }}</span>
                                </li>
                                <li class="list-group-item">
                                    <strong>Department:</strong> <span class="text-success">{{ $user->department->get_Department}}</span>
                                </li>
                                <li class="list-group-item">
                                    <strong>User Role:</strong>
                                    <span class="badge badge-pill badge-primary">{{ $user->userType }}</span>
                                </li>
                                <li class="list-group-item">
                                    <strong>Emp No:</strong>
                                    <span class="badge badge-pill badge-primary">{{ $user->Emp_id }}</span>
                                </li>
                            </ul>

                            <!-- Disabled Input Field -->


                            <!-- Table -->
                            <h4 class="text-dark font-weight-bold mt-4">Recent Activities</h4>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="thead-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Activity</th>
                                        <th>Company Name</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Duration</th>
                                         <th>Extra Time</th>
                                        <th>Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if($user->tasks && $user->tasks->isNotEmpty())
                                        @foreach($user->tasks as $task)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>{{ $task->task_name }}</td>
                                                <td>{{$task->task_site}}</td>
                                               
                                                <td>{{ $task->start_date }}</td>
                                                <td>{{ $task->end_date }}</td>
                                                <td>{{$task->start_time}}</td>
                                                <td>{{$task->end_time}}</td>
                                                <td>{{ $task->Duration_time }}</td>
                                                 <td>{{$task->Extra_time}}</td>


                                                <td>
                 <span class="badge badge-{{ $task->Coordinator_status == 'Done' ? 'success' : ($task->Coordinator_status == 'pending' ? 'warning' : 'secondary') }}">
    {{ ucfirst($task->Coordinator_status) }}
</span>

                                                    </span>


                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="5" class="text-center">No tasks available</td>
                                        </tr>
                                    @endif
                                    </tbody>

                                </table>
                            </div>
                        </div>

                        <!-- Sidebar -->
                        <div class="col-md-4">
                            <div class="sidebar">
                                <div class="card bg-light">
                                    <div class="card-header bg-info text-white">
                                        <h5 class="card-title">Quick Info</h5>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Department:</strong> {{ $user->department->get_Department }}</p>
                                        <p><strong>User Role:</strong> {{ $user->userType }}</p>
                                        <p><strong>Email:</strong> {{ $user->email }}</p>
                                        <p><strong>Emp No:</strong>{{ $user->Emp_id }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card Footer -->
                <div class="card-footer text-center" style="background-color: #e9ecef; border-radius: 0 0 12px 12px;">
                   
                </div>
            </div>
        </div>
    </div>
@endsection
