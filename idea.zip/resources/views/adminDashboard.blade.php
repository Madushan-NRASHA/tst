
@extends('layouts.fonts', ['main_page' => 'yes'])
@section('content')

<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

/* Container */
.container {
    max-width: calc(100% - 250px); /* Adjust based on your sidebar width */
    margin-left: 250px; /* Should match your sidebar width */
    padding: 20px;
}

/* Add spacing between sections */
.filter-form {
    margin: 30px 0;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Improve department card styling */
.kanban-board {
    margin-bottom: 30px;
}

.department-card {
    flex: 1;
    min-width: 300px;
    max-width: calc(33.333% - 20px); /* Ensures 3 cards per row with gap */
    margin-bottom: 20px;
}

/* Department color variations */
.department-header {
    background: linear-gradient(45deg, var(--dept-color), var(--dept-color-light)) !important;
}

/* Add these color variables in your blade template */


/* Kanban Board */
.kanban-board {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

/* Department Card */
.department-card {
    flex: 1;
    min-width: 300px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.department-header {
    padding: 15px;
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.department-body {
    padding: 15px;
    background: #ffffff;
}

/* User List */
.user-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.user-list li {
    padding: 8px;
    border-bottom: 1px solid #ddd;
}

.user-list li:last-child {
    border-bottom: none;
}

/* Task Section */
.task-section {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 20px;
}

.task-card {
    flex: 1;
    min-width: 300px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.task-header {
    padding: 15px;
    font-size: 18px;
    font-weight: bold;
    color: white;
}

.task-body {
    padding: 15px;
}

/* Colors for Task Status */
.bg-primary {
    background-color: #007bff !important;
}

.bg-danger {
    background-color: #dc3545 !important;
}

.bg-success {
    background-color: #28a745 !important;
}

/* Filter Form */
.filter-form {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.filter-form input,
.filter-form select,
.filter-form button {
    padding: 8px;
    font-size: 14px;
    border-radius: 4px;
    border: 1px solid #ddd;
}

.filter-form button {
    background-color: #007bff;
    color: white;
    border: none;
    cursor: pointer;
}

.filter-form button:hover {
    background-color: #0056b3;
}
.current-date {
    background: white;
    padding: 10px 15px;
    border-radius: 4px;
    margin: 20px 0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    font-weight: bold;
}

.task-list {
    list-style-position: inside;
    padding: 0;
    margin: 0;
}

.task-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
    margin: 5px 0;
}

.task-item:last-child {
    border-bottom: none;
}

.task-details {
    margin-top: 5px;
    font-size: 0.9em;
    color: #666;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}

.task-user, .task-date {
    display: inline-block;
    margin-right: 10px;
}

.no-tasks {
    color: #666;
    font-style: italic;
    text-align: center;
    padding: 10px;
}

.task-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Responsive Design */
@media (max-width: 768px) {
    .kanban-board,
    .task-section {
        flex-direction: column;
    }

    .department-card,
    .task-card {
        width: 100%;
    }
}
</style>

<div class="container">
    <h1>Task Management</h1>

    <!-- Kanban Board for Departments -->
    <div class="kanban-board">
        @foreach($departments as $department)
            <div class="department-card">
                <div class="department-header" style="background: {{ $department->color }};">
                    {{ $department->get_Department }}
                </div>
                <div class="department-body">
                    <h6 style="font-weight: bold;">Users</h6>
                    <ul class="user-list">
                        @foreach($department->users as $user)
                            <li>{{ $user->name }} ({{ $user->email }})</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        @endforeach
    </div>

    <!-- Task Filter Form -->
    <form method="GET" action="{{ route('filter.tasks') }}" class="filter-form">
        <input type="text" name="user_name" placeholder="Filter by User Name">
        <input type="date" name="start_date">
        <input type="date" name="end_date">
        <select name="status">
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="ongoing">Ongoing</option>
            <option value="done">Done</option>
        </select>
        <button type="submit">Filter</button>
    </form>
    <div class="current-date">
        Current Date: {{ $now->format('Y-m-d H:i:s') }}
    </div>

    <!-- Task Sections -->
    <div class="task-section">

<div class="task-card">
    <div class="task-header bg-primary">
        Today's Tasks ({{ $todayTasks->count() }})
    </div>
    <div class="task-body">
        <ol class="task-list">
            @forelse($todayTasks as $index => $task)
                <li class="task-item">
                    <strong>{{ $task->task_name }}</strong>
                    <div class="task-details">
                        <span class="task-user">Assigned to: {{ $task->user->name ?? 'N/A' }}</span>
                        <span class="task-date">Created: {{ $task->created_at->format('Y-m-d H:i') }}</span>
                    </div>
                </li>
            @empty
                <p class="no-tasks">No tasks for today</p>
            @endforelse
        </ol>
    </div>
</div>

<!-- Pending Tasks -->
<div class="task-card">
    <div class="task-header bg-danger">
        Pending Tasks ({{ $pendingTasks->count() }})
    </div>
    <div class="task-body">
        <ol class="task-list">
            @forelse($pendingTasks as $index => $task)
                <li class="task-item">
                    <strong>{{ $task->task_name }}</strong>
                    <div class="task-details">
                        <span class="task-user">Assigned to: {{ $task->user->name ?? 'N/A' }}</span>
                        <span class="task-date">Due: {{ $task->end_date }}</span>
                    </div>
                </li>
            @empty
                <p class="no-tasks">No pending tasks</p>
            @endforelse
        </ol>
    </div>
</div>

<!-- Completed Tasks -->
<div class="task-card">
    <div class="task-header bg-success">
        Completed Tasks ({{ $completedTasks->count() }})
    </div>
    <div class="task-body">
        <ol class="task-list">
            @forelse($completedTasks as $index => $task)
                <li class="task-item">
                    <strong>{{ $task->task_name }}</strong>
                    <div class="task-details">
                        <span class="task-user">Completed by: {{ $task->user->name ?? 'N/A' }}</span>
                        <span class="task-date">Completed: {{ $task->updated_at->format('Y-m-d H:i') }}</span>
                    </div>
                </li>
            @empty
                <p class="no-tasks">No completed tasks</p>
            @endforelse
        </ol>
    </div>
</div>
</div>
<script>
    document.querySelectorAll('.department-card').forEach((card, index) => {
        const colors = [
            { main: '#4e73df', light: '#6f8be8' },
            { main: '#1cc88a', light: '#2ed8a1' },
            { main: '#f6c23e', light: '#f8cd60' },
            { main: '#e74a3b', light: '#eb6b5f' },
            { main: '#36b9cc', light: '#4fc9d9' }
        ];
        const colorIndex = index % colors.length;
        card.style.setProperty('--dept-color', colors[colorIndex].main);
        card.style.setProperty('--dept-color-light', colors[colorIndex].light);
    });
</script>
@endsection




