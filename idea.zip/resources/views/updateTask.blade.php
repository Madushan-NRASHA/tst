@extends('layouts.fonts', ['main_page' => 'yes'])

@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1></h1>
                    </div>

                </div>
            </div><!-- /.container-fluid -->
        </section>
        <div class="modal-body">
            <form method="post" action="{{ route('admin.taskUpdateSAVE', ['id' => $task->id]) }}">

            @csrf
                <div class="row">
                    <div class="col-6">
                        <label for="task-site" class="form-label">Company Name</label>
                        <input type="text" id="task-site" name="task_site" value="{{$task->task_site}}" class="form-control" placeholder="Enter task site" >
                    </div>
                    <div class="col-6">
                        <label for="priority" class="form-label">Priority</label>
                        <select id="priority" name="priority" class="form-select" required>
                            <option value="{{$task->priority}}">{{$task->priority}}</option>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <label for="start-date" class="form-label">Start Date</label>
                        <input type="date" id="start-date" value="{{$task->start_date}}" name="start_date" class="form-control" required>
                    </div>
                    <div class="col-6">
                        <label for="end-date" class="form-label">End Date</label>
                        <input type="date" id="end-date" value="{{$task->end_date}}" name="end_date" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <input type="number" id="user-id" name="user_id" hidden class="form-control" value="{{$task->user_id}}" required>
                </div>
                <div class="row">
                  <div class="col-6">
                                        <label for="task-name" class="form-label"  style="position: relative; left: 0px;">Job Description</label>
{{--                                        <textarea id="task-name" name="task_name" class="form-control" placeholder="Enter task name" required>--}}
                      <textarea id="task-name" name="task_name" class="form-control" rows="4" placeholder="Enter task details" required>{{ old('task_name', $task->task_name ?? '') }}</textarea>

                  </div>
                    <div class="col-6">
                        <label for="allocated-by" class="form-label">Allocated By</label>
                        <input type="text" id="allocated-by" name="allocated_by" class="form-control" value="{{ Auth::user()->name }}" placeholder="Enter allocator's name" required disabled>
                    </div>
                </div>

                                        <div class="col-6">
{{--                                            <label for="allocation-hour" class="form-label">Allocation Hour</label>--}}
{{--                                            <input type="number" id="allocation-hour" name="allocation_hour" class="form-control" placeholder="Enter hours" required>--}}
                <!-- Added attributes to make time inputs more user-friendly -->
                                            <!-- Start Time -->

                                            <div class="time-row" style="display: flex; gap: 30px; margin-top: 20px;">
                                                <!-- Start Time -->
                                                <div class="time-selection">
                                                    <label for="start-hour" style="font-weight: bold;">Start Time:</label>
                                                    <div class="time-group" style="display: flex; align-items: center; gap: 5px; margin-top: 5px;">
                                                        <input type="number" id="start-hour" name="start-hour"
                                                               min="1" max="12" value="{{ $hour }}" style="width: 60px;">
                                                        <span>:</span>
                                                        <input type="number" id="start-minute" name="start-minute"
                                                               min="0" max="59" value="{{ $minute }}" style="width: 60px;">
                                                        <select id="start_period" name="start_period" style="padding: 2px;">
                                                            <option value="AM" {{ old('start_period', $period) == 'AM' ? 'selected' : '' }}>AM</option>
                                                            <option value="PM" {{ old('start_period', $period) == 'PM' ? 'selected' : '' }}>PM</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <!-- End Time -->
                                                <div class="time-selection">
                                                    <label for="end-hour" style="font-weight: bold;">End Time:</label>
                                                    <div class="time-group" style="display: flex; align-items: center; gap: 5px; margin-top: 5px;">
                                                        <input type="number" id="end-hour" name="end-hour"
                                                               min="1" max="12" value="{{ $end_hour }}" style="width: 60px;">
                                                        <span>:</span>
                                                        <input type="number" id="end-minute" name="end-minute"
                                                               min="0" max="59" value="{{ $end_minute }}" style="width: 60px;">
                                                        <select id="end_period" name="end_period" style="padding: 2px;">
                                                            <option value="AM" {{ old('end_period', $end_period) == 'AM' ? 'selected' : '' }}>AM</option>
                                                            <option value="PM" {{ old('end_period', $end_period) == 'PM' ? 'selected' : '' }}>PM</option>
                                                        </select>
                                                        <div class="col-auto ms-auto d-flex align-items-center" style="position: relative;top: -5px;left: 350px">
                                                            <p class="fw-bold mb-0 me-2">Duration Hour:</p>
                                                            <input type="number" id="duration-hour" value="{{$task->Duration_time}}" name="getHour" readonly class="form-control w-25"  placeholder="hours">
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                <div id="time-output" style="margin-top: 16px; font-weight: bold; color: #333;"></div>

                                            </div>


                <br>
                <button type="submit"   class="btn btn-success">Update Task</button>

            </form>
        </div>
        <!-- Main content -->

        <!-- /.content -->
        </div>
    <script>
       document.addEventListener("DOMContentLoaded", function () {
    function calculateDuration() {
        let startDate = document.getElementById("start-date").value;
        let endDate = document.getElementById("end-date").value;

        let startHour = Number(document.getElementById("start-hour").value) || 0;
        let startMinute = Number(document.getElementById("start-minute").value) || 0;
        let startPeriod = document.getElementById("start_period").value;

        let endHour = Number(document.getElementById("end-hour").value) || 0;
        let endMinute = Number(document.getElementById("end-minute").value) || 0;
        let endPeriod = document.getElementById("end_period").value;

        if (!startDate || !endDate || startHour === 0 || endHour === 0) {
            document.getElementById("duration-hour").value = "";
            return;
        }

        // Convert to 24-hour format
        if (startPeriod === "PM" && startHour !== 12) startHour += 12;
        if (startPeriod === "AM" && startHour === 12) startHour = 0;
        if (endPeriod === "PM" && endHour !== 12) endHour += 12;
        if (endPeriod === "AM" && endHour === 12) endHour = 0;

        // Create proper date strings
        let startDateTime = `${startDate}T${String(startHour).padStart(2, '0')}:${String(startMinute).padStart(2, '0')}:00`;
        let endDateTime = `${endDate}T${String(endHour).padStart(2, '0')}:${String(endMinute).padStart(2, '0')}:00`;

        // Create Date objects
        let startDateObj = new Date(startDateTime);
        let endDateObj = new Date(endDateTime);

        // Calculate the duration in milliseconds
        let durationMilliseconds = endDateObj - startDateObj;

        // If end time is earlier than start time on the same day, assume it's for the next day
        if (durationMilliseconds < 0) {
            endDateObj.setDate(endDateObj.getDate() + 1);
            durationMilliseconds = endDateObj - startDateObj;
        }

        // Convert milliseconds to hours and minutes
        let durationMinutes = Math.floor(durationMilliseconds / 60000);
        let durationHours = Math.floor(durationMinutes / 60);
        let remainingMinutes = durationMinutes % 60;

        // Format the duration with two decimal places
        let formattedDuration = durationHours + (remainingMinutes > 0 ? "." + String(remainingMinutes).padStart(2, '0') : ".00");
        
        document.getElementById("duration-hour").value = formattedDuration;
    }

    // Attach event listeners to all relevant inputs
    const inputs = ["start-date", "start-hour", "start-minute", "start_period", 
                   "end-date", "end-hour", "end-minute", "end_period"];
    
    inputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener("input", calculateDuration);
            element.addEventListener("change", calculateDuration);
        }
    });

    // Calculate initial duration when page loads
    calculateDuration();
});
    </script>




@endsection
