@extends('layouts.fonts', ['main_page' => 'yes'])
@section('content')

<style>
    /* Department card styling */
    .department-card .card-header {
        background: linear-gradient(45deg, var(--dept-color), var(--dept-color-light)) !important;
    }

    /* Add spacing */
    .row {
        margin-bottom: 20px;
    }

    .card {
        margin-bottom: 20px;
    }

    /* Table improvements */
    .table th {
        background-color: #f8f9fa;
    }

    .table td {
        vertical-align: middle;
    }

    /* Badge styling */
    .badge {
        padding: 8px 12px;
    }
    .task-section {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-top: 20px;
    }

    .task-card {
        flex: 1;
        min-width: 300px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        overflow: hidden;
    }

    .task-header {
        padding: 15px;
        font-size: 18px;
        font-weight: bold;
        color: white;
    }

    .task-body {
        padding: 15px;
    }

    .task-list {
        list-style-position: inside;
        padding: 0;
        margin: 0;
    }

    .task-item {
        padding: 10px;
        border-bottom: 1px solid #eee;
        margin: 5px 0;
    }

    .task-item:last-child {
        border-bottom: none;
    }

    .task-details {
        margin-top: 5px;
        font-size: 0.9em;
        color: #666;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    .task-user, .task-date {
        display: inline-block;
        margin-right: 10px;
    }

    .no-tasks {
        color: #666;
        font-style: italic;
        text-align: center;
        padding: 10px;
    }

    /* Department card colors */
    .department-card .card-header {
        background: linear-gradient(45deg, var(--dept-color), var(--dept-color-light)) !important;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .task-section {
            flex-direction: column;
        }

        .task-card {
            width: 100%;
        }
    }
    </style>


<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Task Management</h1>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <div class="container-fluid">
        <!-- Current Date Display -->
        <div class="alert alert-info">
            Current Date: {{ $now->format('Y-m-d H:i:s') }}
        </div>

        <!-- Kanban Board -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Department Overview</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            @foreach($departments as $department)
                                <div class="col-md-4 mb-4">
                                    <div class="card department-card">
                                        <div class="card-header text-white">
                                            {{ $department->get_Department }}
                                        </div>
                                        <div class="card-body">
                                            <h6 style="font-weight: bold;">Users</h6>
                                            <ul class="list-unstyled">
                                                @foreach($department->users as $user)
                                                    <li class="mb-2">{{ $user->name }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Form -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" action="{{ route('coordinator.filter.tasks') }}" class="row g-3">
                    <div class="col-md-3">
                        <input type="text" name="user_name" class="form-control" placeholder="Filter by User Name">
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="start_date" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <input type="date" name="end_date" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <select name="status" class="form-control">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="done">Done</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Task Tables -->
        <div class="container-fluid">
            <!-- Task Tables Section -->
            <div class="row mb-4">
                <div class="col-12">
                    <!-- Tables Container -->
                    <div class="task-section d-flex flex-wrap gap-4">
                        <!-- Today's Tasks -->
                        <div class="task-card">
                            <div class="task-header bg-primary">
                                Today's Tasks ({{ $todayTasks->count() }})
                            </div>
                            <div class="task-body">
                                <ol class="task-list">
                                    @forelse($todayTasks as $index => $task)
                                        <li class="task-item">
                                            <strong>{{ $task->task_name }}</strong>
                                            <div class="task-details">
                                                <span class="task-user">Assigned to: {{ $task->user->name ?? 'N/A' }}</span>
                                                <span class="task-date">Created: {{ $task->created_at->format('Y-m-d H:i') }}</span>
                                            </div>
                                        </li>
                                    @empty
                                        <p class="no-tasks">No tasks for today</p>
                                    @endforelse
                                </ol>
                            </div>
                        </div>

                        <!-- Pending Tasks -->
                        <div class="task-card">
                            <div class="task-header bg-danger">
                                Pending Tasks ({{ $pendingTasks->count() }})
                            </div>
                            <div class="task-body">
                                <ol class="task-list">
                                    @forelse($pendingTasks as $index => $task)
                                        <li class="task-item">
                                            <strong>{{ $task->task_name }}</strong>
                                            <div class="task-details">
                                                <span class="task-user">Assigned to: {{ $task->user->name ?? 'N/A' }}</span>
                                                <span class="task-date">Due: {{ $task->end_date }}</span>
                                            </div>
                                        </li>
                                    @empty
                                        <p class="no-tasks">No pending tasks</p>
                                    @endforelse
                                </ol>
                            </div>
                        </div>

                        <!-- Completed Tasks -->
                        <div class="task-card">
                            <div class="task-header bg-success">
                                Completed Tasks ({{ $completedTasks->count() }})
                            </div>
                            <div class="task-body">
                                <ol class="task-list">
                                    @forelse($completedTasks as $index => $task)
                                        <li class="task-item">
                                            <strong>{{ $task->task_name }}</strong>
                                            <div class="task-details">
                                                <span class="task-user">Completed by: {{ $task->user->name ?? 'N/A' }}</span>
                                                <span class="task-date">Completed: {{ $task->updated_at->format('Y-m-d H:i') }}</span>
                                            </div>
                                        </li>
                                    @empty
                                        <p class="no-tasks">No completed tasks</p>
                                    @endforelse
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
    document.querySelectorAll('.department-card').forEach((card, index) => {
        const colors = [
            { main: '#4e73df', light: '#6f8be8' },
            { main: '#1cc88a', light: '#2ed8a1' },
            { main: '#f6c23e', light: '#f8cd60' },
            { main: '#e74a3b', light: '#eb6b5f' },
            { main: '#36b9cc', light: '#4fc9d9' }
        ];
        const colorIndex = index % colors.length;
        card.style.setProperty('--dept-color', colors[colorIndex].main);
        card.style.setProperty('--dept-color-light', colors[colorIndex].light);
    });
    </script>
    @endsection