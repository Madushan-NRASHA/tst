@extends('layouts.user',['main_page' > 'yes'])
@section('content')

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1></h1>
                    </div>

                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Post Table</h3>
                            </div>
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                       <th>Company Name</th>
                                        <th>Task Description</th>
                                        <th>Priority</th>
                                        <th>Allocated By</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Duration</th>
                                        <th>Extra Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                        <th>Coordinator Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>


                                        @foreach($tasks as $task)
                                            <tr>
                                                <td>{{$task->task_site}}</td>
                                       <td>{{ $task->task_name }}</td>
                                                
                                            <td>{{ $task->priority }}</td>
                                                <td>{{ $task->allocatedBy->name ?? 'Not specified' }}</td>

                                                <td>{{ $task->start_date }}</td>
                                            <td>{{ $task->end_date }}</td>
                                                <td>{{ $task->start_time }}</td>
                                                <td>{{ $task->end_time }}</td>
                                                <td>{{ $task->Duration_time }}</td>
                                                 <td>{{$task->Extra_time}}</td>
                                                <td>
                                                    @if($task->status == 'pending' )
                                                        <span class="badge badge-success">Pending</span>

                                                    @elseif($task->status = 'Done' )
                                                        <!-- Display 'Done' Status -->
                                                        <span class="badge badge-success">Done</span>
                                                    @else
                                                        <!-- Display 'Done' Status -->
                                                        <span class="badge badge-success">{{$task->status}}</span>
                                                    @endif

                                                </td>
                                                <td>
                                                    @if($task->status != 'Done' )
                                                    <!-- Approve Button (Done) -->
                                                    <form action="{{ route('userTask', ['task' => $task->id]) }}" method="POST" style="display: inline;">
                                                        @csrf
                                                        @method('PUT')
                                                        <input type="hidden" name="status" value="Done">
                                                        <button type="submit" class="btn btn-success btn-sm px-3 py-2" style="font-size: 14px;">Done</button>
                                                    </form>

                                                    <!-- Reject Button (Pending) -->
                                                    <form action="{{ route('userTask', ['task' => $task->id]) }}" method="POST" style="display: inline;">
                                                        @csrf
                                                        @method('PUT')
                                                        <input type="hidden" name="status" value="pending">
                                                        <button type="submit" class="btn btn-warning btn-sm px-3 py-2" style="font-size: 14px;">Pending</button>
                                                    </form>
                                                    @endif
                                                </td>
                                                <td>  <span class="badge badge-{{ $task->Coordinator_status == 'Done' ? 'success' : ($task->Coordinator_status == 'pending' ? 'warning' : 'secondary') }}">
                                                    {{ ucfirst($task->Coordinator_status) }}</td>


                                            </tr>
                                        @endforeach

                                    </tbody>
                                    <tfoot>
                                    <tr>


                                         <th>Company Name</th>
                                        <th>Task </th>
                                        <th>Priority</th>
                                        <th>Allocated By</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Extra Time</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                        <th>Coordinator Status</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- /.content -->
    </div>
@endsection
