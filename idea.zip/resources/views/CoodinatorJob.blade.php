@extends('layouts.fronts', ['main_page' => 'yes'])

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h3>Filter Users by Department</h3>
                    </div>
                </div>
            </div>
        </section>

        <div class="container mt-5">
            <form id="filter-form" class="mb-4">
                @csrf
                <div class="mb-3">
                    <label for="department" class="form-label">Select Department</label>
                    <select id="department" name="department" class="form-select">
                        <option value="">-- Select a Department --</option>
                        @foreach($department as $dep)
                            <option value="{{ $dep->id }}">{{ $dep->get_Department }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="users" class="form-label">Select User</label>
                    <select id="users" name="user" class="form-select" disabled>
                        <option value="">-- Select a User --</option>
                    </select>
                </div>
            </form>

            <div id="user-details" class="mt-4">
                <div class="card" id="user-details-card" style="display: none;">
                    <div class="card-header bg-primary text-white">
                        <h5>User Information</h5>

                    </div>
                    <div class="card-footer text-end">
                        <button type="button" id="add-main-task" class="btn btn-primary">
                            <i class="fas fa-tasks"></i> Add Task
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="modal-body">
                            <form id="main-task-form" method="post" action="{{ route('Coodinator.task.store') }}" style="display: none;">
                                @csrf
                                <div class="row">
                                    <div class="col-6">
                                        <label for="task-site" class="form-label">Company Name</label>
                                        <input type="text" id="task-site" name="task_site" class="form-control" placeholder="Enter task site" >
                                    </div>

                                        <div class="col-6">
                                            <label for="priority" class="form-label">Priority</label>
                                            <select id="priority" name="priority" class="form-select" required>
                                                <option value="">Select priority</option>
                                                <option value="low">Low</option>
                                                <option value="medium">Medium</option>
                                                <option value="high">High</option>
                                            </select>
                                        </div>

                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="start-date" class="form-label">Start Date</label>
                                        <input type="date" id="start-date" name="start_date" class="form-control" required>
                                    </div>
                                    <div class="col-6">
                                        <label for="end-date" class="form-label">End Date</label>
                                        <input type="date" id="end-date" name="end_date" class="form-control" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <input type="number" id="user-id" name="user_id" hidden class="form-control" value="" required>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <label for="task-name" class="form-label"  style="position: relative; left: -400px;">Job Description</label>
                                        {{--                                        <textarea id="task-name" name="task_name" class="form-control" placeholder="Enter task name" required>--}}
                                        <textarea id="task-name" name="task_name" class="form-control" rows="4" placeholder="Enter task details" required></textarea>
                                    </div>
                                    <div class="col-6">
                                        <label for="allocated-by" class="form-label">Allocated By</label>
                                        <input type="text" id="allocated-by" name="allocated_by" class="form-control" value="{{ Auth::user()->name }}" placeholder="Enter allocator's name" required disabled>
                                    </div>
                                </div>
                                {{--                        <div class="col-6">--}}
                                {{--                            <label for="allocation-hour" class="form-label">Allocation Hour</label>--}}
                                {{--                            <input type="number" id="allocation-hour" name="allocation_hour" class="form-control" placeholder="Enter hours" required>--}}
                                <!-- Added attributes to make time inputs more user-friendly -->
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <label for="start-time" class="form-label fw-bold">Start Time:</label>
                                        <div class="d-flex align-items-center gap-2">
                                            <input type="number" id="start-hour" name="start-hour" min="1" max="12" placeholder="HH" class="form-control w-25" required>
                                            <span>:</span>
                                            <input type="number" id="start-minute" name="start-minute" min="0" max="59" placeholder="MM" class="form-control w-25" required>
                                            <select id="start-period" name="start-period" class="form-select w-25" required>
                                                <option value="AM">AM</option>
                                                <option value="PM">PM</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <label for="end-time" class="form-label fw-bold">End Time:</label>
                                        <div class="d-flex align-items-center gap-2">
                                            <input type="number" id="end-hour" name="end-hour" min="1" max="12" placeholder="HH" class="form-control w-25" required>
                                            <span>:</span>
                                            <input type="number" id="end-minute" name="end-minute" min="0" max="59" placeholder="MM" class="form-control w-25" required>
                                            <select id="end-period" name="end-period" class="form-select w-25" required>
                                                <option value="AM">AM</option>
                                                <option value="PM">PM</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div id="time-output" class="mt-3 fw-bold text-dark"></div>
                                    
                                <!--    <div class="row mt-3">-->
                                <!--    <div class="col-12">-->
                                <!--        <label for="remarks" class="form-label">Remarks</label>-->
                                <!--        <textarea id="remarks" name="remarks" class="form-control" rows="3" placeholder="Enter any additional remarks (optional)"></textarea>-->
                                <!--    </div>-->
                                <!--</div>-->





                                <div class="row mt-3 align-items-center">
                                    <div class="col-auto">
                                        <button type="submit" id="submit-time" class="btn btn-success">Save Task</button>
                                        <button type="button" class="btn btn-danger" id="main-task-cancel">Cancel</button>
                                    </div>
                                    <div class="col-auto ms-auto d-flex align-items-center">
                                        <p class="fw-bold mb-0 me-2">Duration Hour:</p>
                                        <input type="number" name="getHour" id="duration-hour" readonly class="form-control w-25" placeholder="hours">
                                    </div>
                                </div>

                            </form>




                        </div>
                    </div>
                    <div class="card-body">
                        <p><strong>Name:</strong> <span id="user-name"></span></p>
                        <p><strong>Department:</strong> <span id="user-department"></span></p>
                        <div id="user-tasks" class="mt-3" style="display: none;">
                            <!-- Tasks will be dynamically loaded here -->
                        </div>
                    </div>


                </div>
            </div>

            <!-- Error Alert (if no users found) -->
            <div id="user-error" class="alert alert-danger mt-4" style="display: none;">
                <strong>Error:</strong> No users found in this department.
            </div>

            <!-- Add Task Form -->

        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>

$(document).ready(function () {
    // Handle department change
    $('#department').on('change', function () {
        const departmentId = $(this).val();

        // Reset user selection and details
        $('#users').prop('disabled', true).html('<option value="">-- Select a User --</option>');
        $('#user-details-card').hide();
        $('#user-error').hide();

        if (!departmentId) return;

        $.ajax({
            url: "{{ route('users.by.department') }}",
            type: "GET",
            data: { department_id: departmentId },
            success: function (response) {
                const usersDropdown = $('#users');
                usersDropdown.prop('disabled', false).html('<option value="">-- Select a User --</option>');

                if (response.users && response.users.length > 0) {
                    response.users.forEach(function(user) {
                        // Fixed: Proper string concatenation for the option element
                        usersDropdown.append('<option value="' + user.id + '">' + user.name + '</option>');
                    });
                } else {
                    $('#user-error').show();
                }
            },
            error: function (xhr) {
                console.error("Error fetching users:", xhr.responseText);
            }
        });
    });

    // Handle user selection
    $('#users').on('change', function () {
        const userId = $(this).val();

        if (!userId) {
            $('#user-details-card').hide();
            return;
        }

        // Set the selected user's ID to the hidden input field
        $('#user-id').val(userId);

        $.ajax({
            url: "{{ route('user.details') }}",
            type: "GET",
            data: { user_id: userId },
            success: function (response) {
                if (response.success) {
                    const user = response.user;

                    $('#user-name').text(user.name);
                    $('#user-department').text(user.department ? user.department.get_Department : 'No department assigned');

                    // Display tasks
                    if (response.tasks && response.tasks.length > 0) {
    let tasksHtml = '';
    response.tasks.forEach(function(task) {
        tasksHtml += '<div class="task-item" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; border-radius: 5px;">' +
            '<strong style="font-size: 1.2rem; color: #333;">Task: ' + task.task_name + '</strong><br>' +
            'Status: <span class="badge ' + (task.status === 'Completed' ? 'bg-success' : task.status === 'In Progress' ? 'bg-warning' : 'bg-secondary') +
            '" style="font-size: 0.9rem;">' + (task.status || 'Not specified') + '</span>' +
            '</div>';

        // Add conditional buttons based on Coordinator_status
        if (task.Coordinator_status !== 'Done') {
            tasksHtml += '<div style="display: flex; gap: 10px; margin-top: 10px;">' +
                '<a href="/Coodinator/ViewUpdate/' + task.id + '" class="text-warning" style="text-decoration: none;">' +
                '<span class="btn btn-warning" style="display: flex; align-items: center;">' +
                '<i class="fas fa-edit" style="margin-right: 5px;"></i> Edit</span></a>' +
                '<a href="/Coodinator/DeleteTask/' + task.id + '" class="text-danger" onclick="confirmDelete(event)" style="text-decoration: none;">' +
                '<span class="btn btn-danger" style="display: flex; align-items: center;">' +
                '<i class="fas fa-trash" style="margin-right: 5px;"></i> Delete</span></a>' +
                '</div>';
        }

        tasksHtml += '<hr style="border-top: 1px solid #ddd; margin-top: 15px;">';
    });
    $('#user-tasks').html(tasksHtml).show();
} else {
    $('#user-tasks').html('<p>No tasks found for this user.</p>').show();
}
                   
                    $('#user-details-card').show();
                } else {
                    console.warn("No user found:", response.message);
                    $('#user-details-card').hide();
                }
            },
            error: function (xhr) {
                console.error("Error fetching user details:", xhr.responseText);
                $('#user-details-card').hide();
            }
        });
    });

    // Add task form toggle
    $('#add-main-task').on('click', function () {
        $('#main-task-form').toggle();
    });

    // Cancel task form
    $('#main-task-cancel').on('click', function () {
        $('#main-task-form').hide();
        $('#main-task-form')[0].reset();
    });
});

// $('#main-task-form').on('submit', function(e) {
//     e.preventDefault();

//     // Log form data before submission
//     console.log('Form Data:', $(this).serialize());

//     // Submit the form
//     this.submit();
// });
        </script>
        <script>
            function confirmDelete(event) {
                event.preventDefault();

                const deleteUrl = event.currentTarget.href; // Ensure we get the correct URL

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This action cannot be undone.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = deleteUrl;
                    }
                });
            }

        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function calculateDuration() {
                    let startHour = parseInt(document.getElementById("start-hour").value) || 0;
                    let startMinute = parseInt(document.getElementById("start-minute").value) || 0;
                    let startPeriod = document.getElementById("start-period").value;

                    let endHour = parseInt(document.getElementById("end-hour").value) || 0;
                    let endMinute = parseInt(document.getElementById("end-minute").value) || 0;
                    let endPeriod = document.getElementById("end-period").value;

                    // Ensure both start and end times are filled before calculating
                    if (startHour === 0 || endHour === 0) {
                        document.getElementById("duration-hour").value = "";
                        return;
                    }

                    // Convert to 24-hour format
                    if (startPeriod === "PM" && startHour !== 12) startHour += 12;
                    if (startPeriod === "AM" && startHour === 12) startHour = 0;
                    if (endPeriod === "PM" && endHour !== 12) endHour += 12;
                    if (endPeriod === "AM" && endHour === 12) endHour = 0;

                    let startTotalMinutes = startHour * 60 + startMinute;
                    let endTotalMinutes = endHour * 60 + endMinute;

                    let durationMinutes = endTotalMinutes - startTotalMinutes;

                    // Adjust for overnight shifts (e.g., 11:00 PM to 6:00 AM)
                    if (durationMinutes < 0) durationMinutes += 24 * 60;

                    let durationHours = Math.floor(durationMinutes / 60);
                    let durationMins = durationMinutes % 60;

                    // Display in HH.MM format
                    document.getElementById("duration-hour").value = durationHours + (durationMins > 0 ? "." + durationMins : "");
                }

                // Attach event listeners
                let inputs = ["start-hour", "start-minute", "start-period", "end-hour", "end-minute", "end-period"];
                inputs.forEach(id => {
                    document.getElementById(id).addEventListener("input", calculateDuration);
                    document.getElementById(id).addEventListener("change", calculateDuration);
                });
            });
        </script>


    </div>
@endsection
